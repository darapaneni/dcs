import os
from ast import Expression
from multiprocessing import context

from NotFound import NotFound
import qrcode
from django.core.serializers import json
from django.http import JsonResponse, HttpResponse, FileResponse, Http404
from django.shortcuts import render
from django.shortcuts import render, redirect
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework import status, generics
from rest_framework.generics import GenericAPIView, UpdateAPIView, ListAPIView
from rest_framework.response import Response
from accounts.models import OneTimePassword,  UserProfilePic
from accounts.serializers import PasswordResetRequestSerializer, LogoutUserSerializer, UserRegisterSerializer, \
    CustomLoginSerializer, SetNewPasswordSerializer, CustomVerifyEmailSerializer, UserDetailsSerializer, \
    UpdateUserSerializer, UserProfilePicSerializer, UserSerializer
from rest_framework import status

from django_rest_auth import settings
from .utils import send_generated_otp_to_email
from django.utils.http import urlsafe_base64_decode
from django.utils.encoding import smart_str, DjangoUnicodeDecodeError
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from rest_framework.permissions import IsAuthenticated
from .models import User
import paypalrestsdk


# Create your views here.


class RegisterView(GenericAPIView):
    serializer_class = UserRegisterSerializer

    def post(self, request):
        user = request.data

        serializer = self.serializer_class(data=user)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            user_data = serializer.data
            send_generated_otp_to_email(user_data['email'], request)
            return Response({
                'data': user_data,
                'message': 'thanks for signing up a passcode has be sent to verify your email'
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class VerifyUserEmail(GenericAPIView):
    serializer_class = CustomVerifyEmailSerializer

    def post(self, request):
        try:
            passcode = request.data.get('otp')
            user_pass_obj = OneTimePassword.objects.get(otp=passcode)
            user = user_pass_obj.user
            print(user.is_verified)
            if not user.is_verified:
                user.is_verified = True
                user.save()
                return Response({
                    'message': 'account email verified successfully'
                }, status=status.HTTP_200_OK)
            elif user.is_verified:
                return Response({'message': 'passcode is invalid user is already verified', 'status': 1},
                                status=status.HTTP_400_BAD_REQUEST)
        except OneTimePassword.DoesNotExist as identifier:
            return Response({'message': 'passcode not valid', 'status': 2}, status=status.HTTP_400_BAD_REQUEST)


class LoginUserView(GenericAPIView):
    serializer_class = CustomLoginSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        if serializer.is_valid():
            validated_data = serializer.validated_data
            return Response(validated_data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # serializer.is_valid(raise_exception=True)
        # print(serializer.errors)
        # user = serializer.validated_data['user']
        # tokens = serializer.validated_data['tokens']
        # return Response({
        #     'user': user.email,
        #     'tokens': tokens
        # }, status=status.HTTP_200_OK)


class PasswordResetRequestView(GenericAPIView):
    serializer_class = PasswordResetRequestSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        return Response({'message': 'we have sent you a link to reset your password'}, status=status.HTTP_200_OK)
        # return Response({'message':'user with that email does not exist'}, status=status.HTTP_400_BAD_REQUEST)


def email_confirmation(request, key):
    return redirect(f"http://localhost:3000/dj-rest-auth/registration/account-confirm-email/{key}")


def reset_password_confirm(request, uid, token):
    return redirect(f"http://localhost:3000/reset/password/confirm/{uid}/{token}")


class PasswordResetConfirm(GenericAPIView):
    serializer_class = PasswordResetRequestSerializer

    def get(self, request, uidb64, token):
        try:
            user_id = smart_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(id=user_id)

            if not PasswordResetTokenGenerator().check_token(user, token):
                return Response({'message': 'token is invalid or has expired'}, status=status.HTTP_401_UNAUTHORIZED)
            return Response({'success': True, 'message': 'credentials is valid', 'uidb64': uidb64, 'token': token},
                            status=status.HTTP_200_OK)

        except DjangoUnicodeDecodeError as identifier:
            return Response({'message': 'token is invalid or has expired'}, status=status.HTTP_401_UNAUTHORIZED)


class SetNewPasswordView(GenericAPIView):
    serializer_class = SetNewPasswordSerializer

    def patch(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'success': True, 'message': "password reset is succesful"}, status=status.HTTP_200_OK)


class TestingAuthenticatedReq(GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        data = {
            'msg': 'its works'
        }
        return Response(data, status=status.HTTP_200_OK)


class LogoutApiView(GenericAPIView):
    serializer_class = LogoutUserSerializer
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(status=status.HTTP_204_NO_CONTENT)


class GetUserByEmailAPIView(GenericAPIView):
    serializer_class = UserDetailsSerializer
    queryset = User.objects.all()
    lookup_field = 'email'

    def get_object(self):
        email = self.kwargs.get('email')
        try:
            return User.objects.get(email=email)
        except User.DoesNotExist:
            raise NotFound(detail="User with this email does not exist.")

    def get(self, request, *args, **kwargs):
        user = self.get_object()
        serializer = self.get_serializer(user)
        return Response(serializer.data)

class ProfilePicUploadView(GenericAPIView):
    permission_classes = [IsAuthenticated]
    parser_classes = (MultiPartParser, FormParser)
    serializer_class = UserProfilePicSerializer
    @swagger_auto_schema(
            operation_description="Upload a profile picture",
            manual_parameters=[
                openapi.Parameter(
                    'profile_pic',
                    openapi.IN_FORM,
                    type=openapi.TYPE_FILE,
                    description='Image file to upload',
                    required=True,
                ),
            ],
            responses={200: 'Profile picture uploaded successfully!'}
        )
    def post(self, request, *args, **kwargs):
        user = request.user  # Get the authenticated user
        if user.is_anonymous:
            return Response({"error": "User not authenticated."}, status=status.HTTP_401_UNAUTHORIZED)
        # Assuming you have an ImageField in your UserProfile model
        profile_pic = request.FILES.get('profile_pic')

        # Check if a file was uploaded
        if not profile_pic:
            return Response({"error": "No file uploaded."}, status=status.HTTP_400_BAD_REQUEST)

        # Get or create a UserProfile instance for the current user
        user_profile, created = UserProfilePic.objects.get_or_create(user=request.user)
        serializer = UserProfilePicSerializer(user_profile, data=request.data)
        user_profile.profile_pic = profile_pic  # Assuming `profile_pic` is an ImageField
        user_profile.save()
        return Response({"message": "Profile picture uploaded successfully!"}, status=status.HTTP_201_CREATED)

# Configure PayPal SDK with client ID and secret
paypalrestsdk.configure({
    "mode": "sandbox",  # Use "live" in production
    "client_id": settings.PAYPAL_CLIENT_ID,
    "client_secret": settings.PAYPAL_CLIENT_SECRET
})
# Create a PayPal order
def create_order(request):
    if request.method == "POST":
        order = paypalrestsdk.Order({
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": "USD",
                    "value": "10.00"  # Set the price here
                }
            }]
        })

        if order.create():
            return JsonResponse({"orderID": order.id})
        else:
            return JsonResponse({"error": "Order creation failed."}, status=500)

# Capture a PayPal order
def capture_order(request):
    if request.method == "POST":
        data = json.loads(request.body)
        order_id = data.get("orderID")

        order = paypalrestsdk.Order.find(order_id)

        if order and order.capture():
            return JsonResponse({"success": True})
        else:
            return JsonResponse({"error": "Order capture failed."}, status=500)

def generate_qr_code(request, order_id):
    # Generate QR Code
    qr = qrcode.make(order_id)
    response = HttpResponse(content_type="image/png")
    qr.save(response, "PNG")
    return response

class UpdateUserProfile(UpdateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = User.objects.all()
    serializer_class = UpdateUserSerializer
    lookup_field = 'pk'
    # lookup_field = 'email'
    # def get_queryset(self):
    #     # Assuming UserProfile has a ForeignKey to User
    #     user = self.request.user
    #     return User.objects.filter(email=user.email)  # Only allow users to update their own profile

    def put(self, request):
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=True)
            serializer.is_valid(raise_exception=True)
            # serializer = UpdateUserSerializer(user, data=request.data, partial=True)  # partial=True for PATCH
            if serializer.is_valid():
                self.perform_update(serializer)
                # serializer.save()
                return JsonResponse(serializer.data, status=status.HTTP_200_OK)
            return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def get(self, request, *args, **kwargs):
        user = request.user  # Get the authenticated user
        serializer = UserSerializer(user)  # Serialize the user data
        return Response(serializer.data)  # Return serialized data



class UserProfilePicUploadView(generics.UpdateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = UserProfilePic.objects.all()
    serializer_class = UserProfilePicSerializer
    lookup_field = 'pk'



class DownloadProfilePicView(GenericAPIView):
    serializer_class = UserProfilePicSerializer
    def get(self,request,user_id ):
        try:
              # Get the latest image for the user
            pic = UserProfilePic.objects.get(user_id=user_id)  # Get the latest image
            print(pic.profile_pic)
            file_path = os.path.join(settings.MEDIA_ROOT, str(pic.profile_pic))  # Adjust the path as necessary
            if os.path.exists(file_path):
                response = FileResponse(open(file_path, 'rb'), content_type='image/jpeg')  # Adjust content type if necessary
                response['Content-Disposition'] = f'attachment; filename="{file_path}"'  # Set the filename for download
                return response
            else:
                raise Http404("Image does not exist")
        except UserProfilePic.DoesNotExist:
            raise Http404("Image does not exist for this user")