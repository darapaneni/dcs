from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils.translation import gettext_lazy as _
from rest_framework_simplejwt.tokens import RefreshToken

from accounts.managers import UserManager
# Create your models here.

AUTH_PROVIDERS ={'email':'email', 'google':'google', 'github':'github', 'linkedin':'linkedin'}

class UserManager(BaseUserManager):
    def create_user(self, email, first_name, last_name, password, **extra_fields):
        if not email:
            raise ValueError(_("Email is required"))
        if not first_name:
            raise ValueError(_("First name is required"))
        if not last_name:
            raise ValueError(_("Last name is required"))
        user = self.model(
            email=self.normalize_email(email),
            first_name=first_name,
            last_name=last_name,
            username=email,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        # user.save(user)
        return user

    def create_superuser(self, email, first_name, last_name, password, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_verified", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("is staff must be true for admin user"))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("is superuser must be true for admin user"))
        user = self.create_user(
            email, first_name, last_name, password, **extra_fields
        )
        return  user

class User(AbstractBaseUser, PermissionsMixin):
    id = models.BigAutoField(primary_key=True, editable=False) 
    email = models.EmailField(
        max_length=255, verbose_name=_("Email Address"), unique=True
    )
    username = models.CharField(max_length=50,verbose_name=_("User Name"))
    first_name = models.CharField(max_length=100, verbose_name=_("First Name"))
    last_name = models.CharField(max_length=100, verbose_name=_("Last Name"))
    address =models.TextField(max_length=500,verbose_name=_("Address"),default='')
    phoneno =models.CharField(max_length=50,verbose_name=_("Phone No"),default='')
    city =models.CharField(max_length=50,verbose_name=_("City"),default='')
    state =models.CharField(max_length=50,verbose_name=_("State"),default='')
    country =models.CharField(max_length=50,verbose_name=_("Country"),default='')
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    is_verified=models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(auto_now_add=True)
    last_login = models.DateTimeField(auto_now=True)
    auth_provider=models.CharField(max_length=50, blank=False, null=False, default=AUTH_PROVIDERS.get('email'))
    profile_picture = models.ImageField(upload_to="profile_pictures", blank=True, null=True)

    USERNAME_FIELD = "email"

    REQUIRED_FIELDS = ["username","first_name", "last_name"]

    objects = UserManager()
    def get_absolute_url(self):
        return f"/users/{self.id}/"

    def get_short_name(self):
        return self.first_name

    def has_perm(self, perm, obj=None):
        return self.is_superuser

    def has_module_perms(self, app_label):
        return True

    def tokens(self):
        refresh = RefreshToken.for_user(self)
        return {
            "refresh":str(refresh),
            "access":str(refresh.access_token)
        }




    def __str__(self):
        return self.email

    @property
    def get_full_name(self):
        return f"{self.first_name.title()} {self.last_name.title()}"

class OneTimePassword(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE)
    otp=models.CharField(max_length=6)


    def __str__(self):
        return f"{self.user.first_name} | {self.user.email}"

class PasswordReset(models.Model):
    pass

class EmailVerification(models.Model):
    pass

# class SocialAccount(models.Model):
#     pass
#
# class PhoneVerification(models.Model):
#     pass
#
# class Profile(models.Model):
#     pass
#
# class Address(models.Model):
#     pass


class UserProfilePic(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,related_name='profile_pic')
    profile_pic = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    def __str__(self):
        return  f"{self.user.username}'s Profile Picture"