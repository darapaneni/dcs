from unicodedata import name
from django.urls import path
from .views import (
    RegisterView,
    VerifyUserEmail,
    LoginUserView,
    PasswordResetConfirm,
    PasswordResetRequestView,
    SetNewPasswordView,
    LogoutApiView, GetUserByEmailAPIView, create_order, capture_order, UpdateUserProfile,
    UserProfilePicUploadView, ProfilePicUploadView,  DownloadProfilePicView)
from rest_framework_simplejwt.views import (TokenRefreshView,)


urlpatterns = [
    path('login/', LoginUserView.as_view(), name='login-user'),
    path('logout/', LogoutApiView.as_view(), name='logout'),
    path('register/', RegisterView.as_view(), name='register'),
    path('users/<str:email>/', GetUserByEmailAPIView.as_view(), name='get-user-by-email'),
    path('verify-email/', VerifyUserEmail.as_view(), name='verify'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('password-reset/', PasswordResetRequestView.as_view(), name='password-reset'),
    path('password-reset-confirm/<uidb64>/<token>/', PasswordResetConfirm.as_view(), name='reset-password-confirm'),
    path('set-new-password/', SetNewPasswordView.as_view(), name='set-new-password'),
    path('paypal/create-order/', create_order, name='create-order'),
    path('paypal/capture-order/', capture_order, name='capture-order'),
    path('profile/<int:pk>/', UpdateUserProfile.as_view(), name='profile-update'),
    path('upload-profile-pic/', ProfilePicUploadView.as_view(), name='upload-profile-pic'),
    path('download/user/<int:user_id>/', DownloadProfilePicView.as_view(), name='download-image-by-user'),
    # path('users/', UserListView.as_view(), name='user-list'),
    # path('users/profile-pic/<int:pk>/', UserProfilePicUploadView.as_view(), name='user-profile-pic'),
    ]