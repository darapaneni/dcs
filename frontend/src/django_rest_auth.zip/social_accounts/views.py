import requests
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from rest_framework.generics import GenericAPIView
from .serializers import GoogleSignInSerializer, GithubLoginSerializer
from rest_framework.response import Response
from rest_framework import status


class GoogleOauthSignInview(GenericAPIView):
    serializer_class=GoogleSignInSerializer

    def post(self, request):
        print(request.data)
        serializer=self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        data=((serializer.validated_data)['access_token'])
        return Response(data, status=status.HTTP_200_OK) 

class GithubOauthSignInView(GenericAPIView):
    serializer_class=GithubLoginSerializer

    def post(self, request, *args, **kwargs):
        serializer=self.serializer_class(data=request.data)
        if serializer.is_valid(raise_exception=True):
            data=((serializer.validated_data)['code'])
            return Response(data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def github_login(request):
        client_id = settings.GITHUB_CLIENT_ID
        redirect_uri = "http://localhost:8000/auth/github/callback"
        return JsonResponse({'url':f'https://github.com/login/oauth/authorize?client_id={client_id}&scope=user:email&redirect_uri={redirect_uri}'})

    def github_callback(request):
        code =request.GET.get('code')
        client_id = settings.GITHUB_CLIENT_ID
        client_secret = settings.GITHUB_SECRET
        # Exchange code for access token
        token_response = requests.post('https://github.com/login/oauth/access_token', data={
            'client_id': client_id,
            'client_secret': client_secret,
            'code': code,
        }, headers={'Accept': 'application/json'})
        token_json = token_response.json()
        access_token = token_json.get('access_token')
        # Use the access token to get user info
        user_response = requests.get('https://api.github.com/user', headers={
            'Authorization': f'token {access_token}',
        })
        user_data = user_response.json()
        # Return user data or create user in your database
        return JsonResponse(user_data)  # Return user data for the frontend to consume
