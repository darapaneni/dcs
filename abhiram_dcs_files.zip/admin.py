# admin.py

from django.contrib import admin
from .models import UserProfile
from django.shortcuts import render
from django.urls import path

admin.site.register(UserProfile)

from django.contrib import admin
from .models import ConsumerRequest45
from django.utils import timezone

@admin.register(ConsumerRequest45)
class ConsumerRequestAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'request_type', 'status', 'response_due_date')
    list_filter = ('status',)
    search_fields = ('name', 'email', 'request_type')
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.filter(response_due_date__lt=timezone.now(), status='pending')

    def overdue_requests_view(self, request):
        overdue_requests = self.get_queryset(request)
        context = {
            'overdue_requests': overdue_requests,
            'title': 'Overdue Consumer Requests'
        }
        return render(request, 'admin/overdue_requests.html', context)
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('overdue-requests/', self.admin_site.admin_view(self.overdue_requests_view), name='overdue-requests'),
        ]
        return custom_urls + urls