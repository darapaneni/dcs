from celery.schedules import crontab
from celery import Celery
app = Celery('dcs')
app.conf.beat_schedule = {
    'check-due-requests-every-hour': {
        'task': 'dcs.tasks.check_due_requests',
        'schedule': crontab(minute='0', hour='*'),  # Every hour
    },
}
