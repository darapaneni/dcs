# apps.py

from django.apps import AppConfig

class MyAppConfig(AppConfig):
    name = 'dcs'

    def ready(self):
        import dcs.signals  # Ensure your signals are imported
