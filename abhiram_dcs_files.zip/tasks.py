from celery import shared_task
from .models import ConsumerRequest
from django.utils import timezone

@shared_task
def notify_admins_of_pending_requests():
    pending_requests = ConsumerRequest.objects.filter(responded_at__isnull=True, created_at__lt=timezone.now() - timezone.timedelta(days=45))
    # Logic to notify admins, e.g., send an email or create a report


from celery import shared_task
from .models import ConsumerRequest
from django.utils import timezone
from django.core.mail import send_mail

@shared_task
def check_due_requests():
    due_requests = ConsumerRequest.objects.filter(status='pending', response_due_date__lt=timezone.now())
    for request in due_requests:
        # Notify the team via email or any other mechanism
        send_mail(
            'Consumer Request Due',
            f'The request from {request.name} is due for response.',
            'mohdajaz2000@gmail.com',
            ['mohdajaz2000@gmail.com'],
        )
