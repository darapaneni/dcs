import streamlit as st
from langchain_core.messages import HumanMessage
from langchain_google_genai import ChatGoogleGenerativeAI
import google.generativeai as genai
import requests
from PIL import Image
import io
import json

# API key for Google Gemini
GOOGLE_GEMINI_KEY = "AIzaSyA3fPRbsDE0mMbCLkuGvgikM-GMMBjzcIc"
llm = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=GOOGLE_GEMINI_KEY)

def extract_dynamic_details(image_bytes):
    # Prompt to extract any available details from the Aadhaar card
    prompt = """
    You are an expert in analyzing and extracting information from Indian Aadhaar cards. The user has provided a URL for an image of an Aadhaar card. Extract any available details you can find, such as:
    - Name (First and Last Name if available)
    - Date of Birth (DOB)
    - Address
    - Pincode
    - Any other relevant information

    Return the details in the following format:
    [Field]: [Value]
    List all available fields you find.
    """

    message = HumanMessage(content=prompt)
    response = llm.invoke([message]).content
    
    # Parse the structured text response dynamically
    try:
        details = {}
        lines = response.split("\n")
        for line in lines:
            if ":" in line:
                key, value = line.split(":", 1)
                details[key.strip().lower().replace(" ", "_")] = value.strip()
        
        # If no details are extracted, return a specific error message
        if not details:
            details = {"error": "No recognizable details could be extracted from the image. Please ensure the image URL is valid and the image is clear."}
        
    except Exception as e:
        details = {"error": "Failed to parse the response. Please check the format and try again."}
    
    return details

# Streamlit interface
st.title("Aadhaar Card Details Extractor")

image_url = st.text_input("Enter the URL of your Aadhaar card image")

if image_url:
    try:
        # Fetch the image from the URL
        response = requests.get(image_url)
        image_bytes = response.content
        
        # Display the image
        image = Image.open(io.BytesIO(image_bytes))
        st.image(image, caption="Uploaded Aadhaar Card", use_column_width=True)

        # Submit button for extraction
        if st.button("Submit"):
            # Extract details dynamically using the function
            output = extract_dynamic_details(image_bytes)
            
            # Display the extracted details
            st.json(output)
            
    except Exception as e:
        st.error("Error loading the image. Please check the URL and try again.")
