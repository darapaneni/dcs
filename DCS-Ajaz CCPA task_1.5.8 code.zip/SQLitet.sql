-- SQLite
update dcs_consumerrequest45 set response_due_date=DATE('now','-1 day');
commit;