# forms.py
from django import forms

class DataAccessRequestForm(forms.Form):
    email = forms.EmailField()

class DataDeletionRequestForm(forms.Form):
    email = forms.EmailField()
    
class UserConsentForm(forms.Form):
     #email = forms.EmailField()
     consent = forms.BooleanField(
        required=True,
        label="I consent to the collection and processing of my personal data according to the Privacy Policy."
    )

from .models import ConsumerRequest, PrivacyPreference, PersonalData

class ConsumerRequestForm(forms.ModelForm):
    class Meta:
        model = ConsumerRequest
        fields = ['name', 'email','request_type', 'description']
        
class PrivacyPreferenceForm(forms.ModelForm):
    class Meta:
        model = PrivacyPreference
        fields = ['do_not_sell']
        
        
from django import forms
from .models import DataSource, DataFlow, DataTransformation

class DataSourceForm(forms.ModelForm):
    class Meta:
        model = DataSource
        fields = ['name', 'description']

class DataFlowForm(forms.ModelForm):
    class Meta:
        model = DataFlow
        fields = ['source', 'destination', 'data_type']

class DataTransformationForm(forms.ModelForm):
    class Meta:
        model = DataTransformation
        fields = ['flow', 'transformation_type', 'description']

class PersonalDataForm(forms.ModelForm):
    class Meta:
        model = PersonalData
        fields = ['data_type', 'data_value', 'retention_period_days']

from django import forms

class DoNotSellForm(forms.Form):
    email = forms.EmailField(label="Your Email", max_length=254)

from django import forms
from .models import DataMapping

class DataMappingForm(forms.ModelForm):
    class Meta:
        model = DataMapping
        fields = ['data_type', 'source', 'purpose', 'storage_location', 'access_points', 'sharing', 'third_party', 'retention_period']


from django import forms
from .models import ConsumerRequest45

class ConsumerRequestForm45(forms.ModelForm):
    class Meta:
        model = ConsumerRequest45
        fields = ['name', 'email', 'request_type', 'description']
