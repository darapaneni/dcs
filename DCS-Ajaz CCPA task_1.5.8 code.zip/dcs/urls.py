"""
URL configuration for dcs project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.shortcuts import render
from django.urls import path,include
from django.urls import path
from .views import data_access_request, data_deletion_request, user_consent_view ,submit_request, my_requests, request_success
from .views import privacy_preference, privacy_success, respond_to_request, request_data_access,download_data 
from .views import (
    create_data_source,
    create_data_flow,
    create_data_transformation,
    data_source_list,
    data_flow_list,
    data_transformation_list,
    do_not_sell_view,
    create_data_mapping,
    data_mapping_list,
    submit_request45,
    request_success45,
    list_requests45,
    handle_request45,
    check_due_requests,
)

def home(request):
    return render(request,'home.html')

def privacy_view(request):
    return render(request, 'privacy.html')

def data_access_request_view(request):
    return render(request, 'data_access_request.html')

def data_deletion_request_view(request):
    return render(request, 'data_deletion_request.html')

def user_consent_view_view(request):
    return render(request, 'User_Consent_Form.html')

def submit_request_view(request):
    return render(request, 'submit_request.html')

def my_requests_view(request):
    return render(request, 'my_requests.html')

urlpatterns = [
    path('', home),
    path('privacy/', privacy_view, name='privacy'),
    path("admin/", admin.site.urls),
    path('accounts/', include('allauth.urls')),  # Social account URLs
    path('consent/', user_consent_view, name='user_consent'),
    path('data-access-request/', data_access_request, name='data_access_request'),
    path('data-deletion-request/', data_deletion_request, name='data_deletion_request'),
    path('submit/', submit_request, name='submit_request'),
    path('my-requests/', my_requests, name='my_requests'),
    path('success/', request_success, name='request_success'),
    path('privacy-preference/', privacy_preference, name='privacy_preference'),
    path('do-not-sell/', do_not_sell_view, name = 'do_not_sell' ),
    path('privacy-success/', privacy_success, name='privacy_success'),
    path('data-source/create/', create_data_source, name='create_data_source'),
    path('data-flow/create/', create_data_flow, name='create_data_flow'),
    path('data-transformation/create/', create_data_transformation, name='create_data_transformation'),
    path('data-sources/', data_source_list, name='data_source_list'),
    path('data-flows/', data_flow_list, name='data_flow_list'),
    path('data-transformations/', data_transformation_list, name='data_transformation_list'),
    path('respond/<int:request_id>/', respond_to_request, name='respond_to_request'),
    path('request-data-access/', request_data_access, name='request_data_access'),
    path('download-data/', download_data, name='download_data'),
    path('data-mapping/create/', create_data_mapping, name='create_data_mapping'),
    path('data-mapping/', data_mapping_list, name='data_mapping_list'),
    path('submit45/', submit_request45, name='submit_request45'),
    path('success45/', request_success45, name='request_success45'),
    path('list45/', list_requests45, name='list_requests45'),
    path('handle45/<int:request_id>/', handle_request45, name='handle_request45'), 
    path('check_due/', check_due_requests, name='check_due_requests'),
]
