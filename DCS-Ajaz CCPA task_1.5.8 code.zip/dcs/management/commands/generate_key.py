from django.core.management.base import BaseCommand
from cryptography.fernet import Fernet

class Command(BaseCommand):
    help = 'Generate a new encryption key.'

    def handle(self, *args, **kwargs):
        key = Fernet.generate_key()
        print(f"Your new encryption key is: {key.decode()}")