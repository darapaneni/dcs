from django.core.management.base import BaseCommand
from django.utils import timezone
from dcs.models import PersonalData
from django.db.models import F

#class Command(BaseCommand):
#    help = 'Delete personal data that has exceeded its retention period'

#    def handle(self, *args, **kwargs):
#       expired_data = PersonalData.objects.filter(
#            created_at__lt=timezone.now() - timezone.timedelta(days=F('retention_period_days'))
#        )
#        count = expired_data.count()
#        expired_data.delete()
#        self.stdout.write(self.style.SUCCESS(f'Successfully deleted {count} expired data records.'))



class Command(BaseCommand):
    help = 'Delete personal data that has exceeded its retention period'

    def handle(self, *args, **kwargs):
        # Get the current time
        now = timezone.now()

        # Calculate expired data based on retention periods
        expired_data = PersonalData.objects.filter(
            created_at__lt=now - timezone.timedelta(days=1)  # Default retention period
        )

        for data in expired_data:
            # Check each entry's retention period
            retention_period = data.retention_period_days
            if data.created_at < now - timezone.timedelta(days=retention_period):
                data.delete()

        count = expired_data.count()
        self.stdout.write(self.style.SUCCESS(f'Successfully deleted {count} expired data records.'))