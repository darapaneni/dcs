# views.py
from django.shortcuts import render
from django.core.mail import send_mail
from .forms import DataAccessRequestForm
from django.utils import timezone

def data_access_request(request):
    if request.method == 'POST':
        form = DataAccessRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            # Implement logic to fetch user data
            # For example, send an email to admin with data access request details
            send_mail(
                'Data Access Request',
                f'User with email {email} has requested data access.',
                'from@example.com',
                ['admin@example.com'],
                fail_silently=False,
            )
            return render(request, 'request_success.html')
    else:
        form = DataAccessRequestForm()
    return render(request, 'data_access_request.html', {'form': form})


from .forms import DataDeletionRequestForm

def data_deletion_request(request):
    if request.method == 'POST':
        form = DataDeletionRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            # Implement logic to delete user data
            # For example, send an email to admin with data deletion request details
            send_mail(
                'Data Deletion Request',
                f'User with email {email} has requested data deletion.',
                'from@example.com',
                ['admin@example.com'],
                fail_silently=False,
            )
            return render(request, 'request_success.html')
    else:
        form = DataDeletionRequestForm()
    return render(request, 'data_deletion_request.html', {'form': form})

from django.shortcuts import render, redirect
from .forms import UserConsentForm

def user_consent_view(request):
    if request.method == 'POST':
        form = UserConsentForm(request.POST)
        if form.is_valid():
            # Process the consent (e.g., save it to the database or proceed with user registration)
            # For example, you could save the consent status to the user's profile
            request.session['consent_given'] = True  # This is just an example, adjust as needed
            return redirect('success_url')  # Redirect to a success page or home page
    else:
        form = UserConsentForm()
    
    return render(request, 'user_consent.html', {'form': form})

from django.shortcuts import render, redirect
from .forms import ConsumerRequestForm, PrivacyPreferenceForm
from .models import ConsumerRequest, PrivacyPreference
from django.contrib.auth.decorators import login_required

#@login_required
#def submit_request(request):
#    if request.method == 'POST':
#        form = ConsumerRequestForm(request.POST)
#        if form.is_valid():
#            consumer_request = form.save(commit=False)
#            consumer_request.user = request.user
#            consumer_request.save()
#            return redirect('request_success')
#    else:
#        form = ConsumerRequestForm()
#    return render(request, 'submit_request.html', {'form': form})

@login_required
def submit_request(request):
    if request.method == 'POST':
        request_type = request.POST.get('request_type')
        details = request.POST.get('details')
        ConsumerRequest.objects.create(user=request.user, request_type=request_type, description=details)
        return redirect('my_requests')  # Redirect to the list after submission
    return render(request, 'submit_request.html')

@login_required
def my_requests(request):
    requests = ConsumerRequest.objects.filter(user=request.user)
    return render(request, 'my_requests.html', {'requests': requests})

def request_success(request):
    return render(request, 'request_success.html')

@login_required
def respond_to_request(request, request_id):
    consumer_request = ConsumerRequest.objects.get(id=request_id)
    if request.method == 'POST':
        consumer_request.responded_at = timezone.now()
        consumer_request.status = 'Responded'
        consumer_request.save()
        return redirect('my_requests')
    return render(request, 'respond_request.html', {'request': consumer_request})


@login_required
def privacy_preference(request):
    preference, created = PrivacyPreference.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = PrivacyPreferenceForm(request.POST, instance=preference)
        if form.is_valid():
            form.save()
            return redirect('privacy_success')
    else:
        form = PrivacyPreferenceForm(instance=preference)

    return render(request, 'privacy_preference.html', {'form': form})

def privacy_success(request):
    return render(request, 'privacy_success.html')


from django.shortcuts import render, redirect
from .forms import DataSourceForm, DataFlowForm, DataTransformationForm
from .models import DataSource, DataFlow, DataTransformation

def create_data_source(request):
    if request.method == 'POST':
        form = DataSourceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('data_source_list')
    else:
        form = DataSourceForm()
    return render(request, 'create_data_source.html', {'form': form})

def create_data_flow(request):
    if request.method == 'POST':
        form = DataFlowForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('data_flow_list')
    else:
        form = DataFlowForm()
    return render(request, 'create_data_flow.html', {'form': form})

def create_data_transformation(request):
    if request.method == 'POST':
        form = DataTransformationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('data_transformation_list')
    else:
        form = DataTransformationForm()
    return render(request, 'create_data_transformation.html', {'form': form})

def data_source_list(request):
    sources = DataSource.objects.all()
    return render(request, 'data_source_list.html', {'sources': sources})

def data_flow_list(request):
    flows = DataFlow.objects.all()
    return render(request, 'data_flow_list.html', {'flows': flows})

def data_transformation_list(request):
    transformations = DataTransformation.objects.all()
    return render(request, 'data_transformation_list.html', {'transformations': transformations})

from django.shortcuts import render, redirect
from .models import PersonalData
from .forms import PersonalDataForm  # Assuming you have a form for this

@login_required
def update_data_retention(request, data_id):
    data_record = PersonalData.objects.get(id=data_id, user=request.user)
    
    if request.method == 'POST':
        form = PersonalDataForm(request.POST, instance=data_record)
        if form.is_valid():
            form.save()
            return redirect('success_page')  # Redirect to a success page
    else:
        form = PersonalDataForm(instance=data_record)

    return render(request, 'update_retention.html', {'form': form})

@login_required
def request_success(request):
    return render(request, 'request_success.html')

@login_required
def request_data_access(request):
    if request.method == 'POST':
        ConsumerRequest.objects.create(user=request.user, request_type='data_access')
        return redirect('request_success')  # Redirect after submission
    return render(request, 'request_data_access.html')

from django.http import JsonResponse
import json

@login_required
def download_data(request):
    # Get the user’s data
    user_data = {
        'username': request.user.username,
        'email': request.user.email,
        # Add any other fields you want to include
    }
    return JsonResponse(user_data)  # You can return CSV or other formats if needed


from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import DoNotSellForm
from .models import DoNotSellRequest

def do_not_sell_view(request):
    if request.method == 'POST':
        form = DoNotSellForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            # Check if the email already exists
            if not DoNotSellRequest.objects.filter(email=email).exists():
                DoNotSellRequest.objects.create(email=email)
                messages.success(request, 'Your request has been submitted successfully.')
            else:
                messages.info(request, 'You have already submitted a request with this email.')
            return redirect('do_not_sell')
    else:
        form = DoNotSellForm()
    
    return render(request, 'do_not_sell.html', {'form': form})

from django.shortcuts import render, redirect
from .models import DataMapping
from .forms import DataMappingForm

def create_data_mapping(request):
    if request.method == 'POST':
        form = DataMappingForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('data_mapping_list')
    else:
        form = DataMappingForm()
    
    return render(request, 'create_data_mapping.html', {'form': form})

def data_mapping_list(request):
    mappings = DataMapping.objects.all()
    return render(request, 'data_mapping_list.html', {'mappings': mappings})


from django.shortcuts import render, redirect
from .forms import ConsumerRequestForm, ConsumerRequestForm45
from .models import ConsumerRequest45
from django.contrib import messages

def submit_request45(request):
    if request.method == 'POST':
        form = ConsumerRequestForm45(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Request submitted successfully.')
            return redirect('request_success45')
    else:
        form = ConsumerRequestForm()
    return render(request, 'submit_request45.html', {'form': form})

def request_success45(request):
    return render(request, 'request_success45.html')

def list_requests45(request):
    requests = ConsumerRequest45.objects.all()
    return render(request, 'list_requests45.html', {'requests': requests})

def handle_request45(request, request_id):
    consumer_request = ConsumerRequest45.objects.get(id=request_id)
    if request.method == 'POST':
        # Update status as needed
        consumer_request.status = 'resolved'  # or 'rejected'
        consumer_request.save()
        messages.success(request, 'Request status updated.')
        return redirect('list_requests45')
    return render(request, 'handle_request45.html', {'request': consumer_request})

def check_due_requests(request):
    overdue_requests = ConsumerRequest45.objects.filter(status='pending', response_due_date__lt=timezone.now())
    #overdue_requests = ConsumerRequest45.objects.filter(status='pending', response_due_date__gt = timezone.now())
    return render(request, 'check_due_requests.html', {'overdue_requests': overdue_requests})




