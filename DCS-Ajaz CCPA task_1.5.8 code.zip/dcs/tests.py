# tests.py

from django.test import TestCase
from .models import UserProfile
from django.contrib.auth.models import User
from dcs.models import UserProfile

class EncryptionTestCase(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(username='testuser', password='testpassword')
        self.user_profile, created = UserProfile.objects.get_or_create(user=self.user, defaults={'sensitive_data': 'Secret Data'})

    def test_user_profile_creation(self):
        self.assertIsNotNone(self.user_profile)
        
    def test_encryption(self):
        # Retrieve the user profile from the database
        profile = UserProfile.objects.get(user=self.user)
        # Verify that the sensitive data can be decrypted correctly
        decrypted_data = profile.sensitive_data
        self.assertEqual(decrypted_data, 'Secret Data')

    def test_data_is_encrypted_in_db(self):
        # Check that the data stored in the database is not the same as the original
        profile = UserProfile.objects.get(user=self.user)
        self.assertNotEqual(profile.sensitive_data, 'Secret Data')
