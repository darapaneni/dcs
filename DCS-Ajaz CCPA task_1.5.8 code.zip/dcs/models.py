# models.py

from django.db import models
from cryptography.fernet import Fernet
import os
from django.contrib.auth.models import User
from django.utils import timezone

ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY')
fernet = Fernet(ENCRYPTION_KEY)

def encrypt(data):
    return fernet.encrypt(data.encode()).decode()

def decrypt(data):
    return fernet.decrypt(data.encode()).decode()


class EncryptedTextField(models.TextField):
    def __init__(self, *args, **kwargs):
        self.cipher = Fernet(os.environ['ENCRYPTION_KEY'])
        super().__init__(*args, **kwargs)

    def get_prep_value(self, value):
        if value is None:
            return value
        return self.cipher.encrypt(value.encode()).decode()

    def from_db_value(self, value, expression, connection):
        if value is None:
            return value
        return self.cipher.decrypt(value.encode()).decode()

#class UserProfile(models.Model):
#    user = models.OneToOneField('auth.User', on_delete=models.CASCADE)
#    sensitive_data = EncryptedTextField()

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    sensitive_data = models.TextField()
    
    def save(self, *args, **kwargs):
        if self.sensitive_data:
            self.sensitive_data = encrypt(self.sensitive_data)  # Call your encryption function
        super().save(*args, **kwargs)
    
    #def get_sensitive_data(self):
    #    return decrypt(self.sensitive_data)  # Call your decryption function
      
    def get_sensitive_data(self):
        decrypted = decrypt(self.sensitive_data) if self.sensitive_data else ''
        print(f"Decrypted Data: {decrypted}")
        return decrypted
        
        #return decrypt(self.sensitive_data) if self.sensitive_data else ''

from django.db import models
from django.contrib.auth.models import User

class ConsumerRequest(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Resolved', 'Resolved'),
    ]

    REQUEST_TYPES = [
        ('do_not_sell', 'Do Not Sell My Personal Information'),
        ('data_access', 'Request for Data Access'),
        ('data_deletion', 'Request for Data Deletion'),
        ('data_download', 'Request for user data download'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    email = models.EmailField()
    request_type = models.CharField(max_length=20, choices=REQUEST_TYPES)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='Pending')

    def is_expired(self):
        if self.responded_at:
            return False
        return (timezone.now() - self.created_at).days > 45

    def __str__(self):
        return f"{self.request_type} by {self.user.username} - {self.status}"
        #return f"{self.user.username}: {self.get_request_type_display()} ({self.status})"

class PrivacyPreference(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    do_not_sell = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - Do Not Sell: {self.do_not_sell}"
    


from django.db import models
from django.contrib.auth.models import User

class DataSource(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

class DataFlow(models.Model):
    source = models.ForeignKey(DataSource, on_delete=models.CASCADE)
    destination = models.CharField(max_length=255)
    data_type = models.CharField(max_length=255)  # e.g., "Email", "Phone Number"
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.source.name} -> {self.destination} ({self.data_type})"

class DataTransformation(models.Model):
    flow = models.ForeignKey(DataFlow, on_delete=models.CASCADE)
    transformation_type = models.CharField(max_length=255)  # e.g., "Anonymization"
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.transformation_type} on {self.flow}"


class PersonalData(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    data_type = models.CharField(max_length=255)  # e.g., "Email", "Phone Number"
    data_value = models.TextField()  # The actual data
    created_at = models.DateTimeField(auto_now_add=True)
    retention_period_days = models.PositiveIntegerField(default=30)  # Retention period in days

    def __str__(self):
        return f"{self.user.username}: {self.data_type}"

from django.db import models

class DoNotSellRequest(models.Model):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email

from django.db import models

class DataMapping(models.Model):
    DATA_TYPE_CHOICES = [
        ('name', 'Name'),
        ('email', 'Email'),
        ('phone', 'Phone Number'),
        ('address', 'Address'),
        ('payment_info', 'Payment Information'),
        ('preferences', 'User Preferences'),
        ('ip_address', 'IP Address'),
    ]

    data_type = models.CharField(max_length=50, choices=DATA_TYPE_CHOICES)
    source = models.CharField(max_length=255)
    purpose = models.TextField()
    storage_location = models.CharField(max_length=255)
    access_points = models.TextField()
    sharing = models.BooleanField(default=False)
    third_party = models.CharField(max_length=255, blank=True, null=True)
    retention_period = models.CharField(max_length=255, blank=True, null=True)  # Add this line


    def __str__(self):
        return f"{self.data_type} - {self.source}"


from django.db import models
from django.utils import timezone

class ConsumerRequest45(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('rejected', 'Rejected'),
    ]
    REQUEST_TYPES = [
        ('do_not_sell', 'Do Not Sell My Personal Information'),
        ('data_access', 'Request for Data Access'),
        ('data_deletion', 'Request for Data Deletion'),
        ('data_download', 'Request for user data download'),
    ]
    name = models.CharField(max_length=100)
    email = models.EmailField()
    request_type = models.CharField(max_length=50, choices=REQUEST_TYPES)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    response_due_date = models.DateTimeField()
    

    def save(self, *args, **kwargs):
        # Set response_due_date if it is not already set
        if not self.response_due_date:
            self.response_due_date = self.created_at + timezone.timedelta(days=45) if self.created_at else timezone.now() + timezone.timedelta(days=45)
        super().save(*args, **kwargs)


    def is_due(self):
        return timezone.now() > self.response_due_date

    def __str__(self):
        return f"{self.name} - {self.request_type} ({self.status})"
